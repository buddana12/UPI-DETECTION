var str = document.getElementById("output").innerHTML;
if (str == "VALID TRANSACTION")
    document.getElementById("output").style.color = "green";
else
    document.getElementById("output").style.color = "red";